package hr.fer.zemris.java.custom.scripting.elems;

/**
 * Represents the top element of the Element hierarchy
 * 
 * @author Tomislav Kurtović
 *
 */
public class Element {

	public String asText() {
		return "";
	}
	
}
